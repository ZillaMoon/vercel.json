# Zilla News starter

## Preview
Open `index.html` in a browser. For a better local preview, serve this folder with a local static web server.

## Important demo limitations
- The sign-in/register interface is a front-end demo only. It stores a demo identity in browser localStorage and does NOT authenticate users securely. Do not collect real passwords with this version.
- Saved stories and theme preferences are stored in the current browser only.
- Newsletter form is a visual demo and does not send or store email addresses.
- Stories are illustrative placeholders, not live news. Replace with original, verified reporting before launch.
- Images load from Unsplash and need an internet connection.

## Before public launch
1. Connect secure authentication (for example, a server-side auth provider) and implement password reset, email verification, session handling, abuse prevention and account deletion.
2. Connect a CMS/editorial workflow or a reliable, licensed news data source. Do not scrape and republish other publishers' articles.
3. Replace `https://zilla.com/` canonical/OG URLs if your final domain differs.
4. Publish complete Privacy Policy, Terms, About, Contact, Corrections and Editorial Standards pages with real information.
5. Create and submit an XML sitemap in Google Search Console; check robots.txt, canonical URLs, mobile usability, Core Web Vitals and structured data.
6. Apply for AdSense only after the site has substantial original content and complies with all policies. Replace ad placeholders with the exact code provided in your approved AdSense account; never encourage ad clicks.
7. Add consent management appropriate for your visitors and advertising setup.
8. Configure HTTPS, backups, monitoring, security headers and server-side validation.

This project is a starter template, not a guarantee of search ranking or ad approval.
