// Public browser configuration only. These values are not passwords.
// Supabase publishable/anon key is designed to be used in the browser.
// NEVER put the service_role/secret key in this file.
window.ZILLA_CONFIG = {
  SUPABASE_URL: "https://YOUR_PROJECT_REF.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY"
};
