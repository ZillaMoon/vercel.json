ZILLA NEWS — SECURE AUTH STARTER
================================

WHAT IS INCLUDED
- Responsive Zilla News front end with category navigation, search, saved demo stories and dark/light mode.
- Supabase Auth integration for registration, password sign-in, email confirmation, password recovery and password updates.
- Vercel-ready static hosting structure.
- SEO metadata and schema starter.
- Sample articles are placeholders. They are not live news and must be replaced with original, verified reporting.

IMPORTANT SECURITY NOTES
- This uses Supabase Auth; passwords are handled by Supabase, not saved by your own JavaScript.
- config.js contains only your Supabase project URL and publishable/anon key. A browser anon/publishable key is expected to be public; protect data with Row Level Security if you later add tables.
- NEVER put a Supabase service_role key, database password, SMTP password or other secret in browser files or GitHub.
- If Supabase is not configured, the login form intentionally reports that configuration is needed.
- Supabase may require email confirmation, depending on your Auth settings.
- Use a strong password and enable any available account security protections.

DEPLOYMENT: SUPABASE + VERCEL (RECOMMENDED)
1. Create a Supabase project at https://supabase.com/ and save its project URL and publishable/anon key from Project Settings / API.
2. In this folder, edit public/config.js:
   SUPABASE_URL = "https://YOUR_PROJECT_REF.supabase.co"
   SUPABASE_ANON_KEY = "YOUR_PUBLIC_PUBLISHABLE_OR_ANON_KEY"
   Use the project's publishable key or legacy anon key only. Do not use service_role.
3. In Supabase Dashboard > Authentication > URL Configuration:
   - Set Site URL to your production website origin, e.g. https://zilla.com
   - Add Redirect URLs for your production origin and local testing origin, e.g. http://localhost:8000/** and https://your-deployment.vercel.app/**
   - Ensure the password-recovery redirect is allowed.
4. In Supabase Dashboard > Authentication > Providers > Email, configure email confirmation to match your desired registration flow. For production, configure a reliable custom SMTP provider and sender domain according to Supabase docs; default email sending has limitations.
5. In Supabase email templates, customize the confirmation and password-recovery email content. Test both on an email address you control.
6. Test locally: from this project folder run `python -m http.server 8000` then visit http://localhost:8000. (If Python isn't installed, use another local static server.)
7. Create a GitHub repository and upload the project contents so `index.html`, `vercel.json`, and the `public` folder are at repository root.
8. Import the repository at https://vercel.com/new. This is a static site: no build command is required. The included vercel.json routes the public folder as the site root. Deploy.
9. Add your custom domain in Vercel and complete the DNS steps Vercel displays. Enable HTTPS; Vercel handles the certificate.
10. Add the final domain to Supabase Site URL and Redirect URLs. Update canonical URL, Open Graph URL, JSON-LD URL and contact email in public/index.html.
11. Verify registration confirmation, sign-in, forgot-password email, password update, sign-out and mobile layout on the deployed HTTPS site.

LOCAL SERVER STRUCTURE
- public/index.html
- public/style.css
- public/script.js
- public/config.js
- vercel.json

MONETIZATION AND SEARCH CHECKLIST
- Replace all demo/sample stories with original, fact-checked content; clearly identify authors and publication/update dates.
- Publish real About, Contact, Privacy Policy, Terms, Corrections and Editorial Standards pages.
- Create an XML sitemap and robots.txt; submit sitemap in Google Search Console.
- Use a unique URL for each real article. For production news publishing, render article content into crawlable HTML and add valid Article/NewsArticle structured data per article.
- Use canonical URLs that match the final domain.
- Improve performance, image optimization, accessibility, mobile layout and Core Web Vitals.
- Apply for AdSense only when the site has substantial original value and complies with current publisher policies. Approval and revenue are not guaranteed.
- Add a suitable consent/privacy notice for analytics and advertising where required. Never encourage clicks on ads.
- This starter's demo article cards do not create independent SEO article pages and are not a complete live news CMS.

TROUBLESHOOTING
- “Authentication is not configured”: check public/config.js and reload.
- Email confirmation or recovery link redirects incorrectly: check Supabase Auth URL Configuration and the deployed origin.
- Emails not delivered: inspect Supabase Auth logs and configure custom SMTP for production.
- Never bypass redirect allowlists or expose secret keys to fix a setup issue.
